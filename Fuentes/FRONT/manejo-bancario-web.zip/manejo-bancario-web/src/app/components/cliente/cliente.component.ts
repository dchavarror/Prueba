import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Cliente } from 'src/app/domain/cliente';
import { ClienteService } from '../../services/cliente.service';
import { Respuesta } from '../../domain/respuesta';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css'],
})
export class ClienteComponent implements OnInit {
  clienteForm: FormGroup;
  actClienteForm: FormGroup;
  lstClientes: Cliente[] = [];
  cliente: Cliente;
  respuesta: Respuesta;
  message: string;
  messageConf: string;
  indValidacion: boolean;
  modalres = 'none';
  modalconf = 'none';
  modalactcl = 'none';
  modaleli = 'none';
  idCliente = 0;
  pnombre ="";

  constructor(private serviceCliente: ClienteService, private fb: FormBuilder) {
    this.clienteForm = this.inicializarComponentesClie();
    this.actClienteForm = this.inicializarComponentesClieAct();
    this.getClientes();
    this.cliente = new Cliente();
    this.respuesta = new Respuesta();
    this.message = '';
    this.messageConf = '';
    this.indValidacion = false;
  }

  ngOnInit(): void {}
  get obtenerClienteForm() {
    return this.clienteForm.controls;
  }
  get obtenerClienteActForm() {
    return this.actClienteForm.controls;
  }

  inicializarComponentesClie() {
    return (this.clienteForm = this.fb.group({
      pnombre: new FormControl(),
      ptelefono: new FormControl(),
      pdireccion: new FormControl(),
    }));
  }

  inicializarComponentesClieAct() {
    return (this.actClienteForm = this.fb.group({
      pnombrea: new FormControl(),
      ptelefonoa: new FormControl(),
      pdirecciona: new FormControl(),
    }));
  }

  getClientes() {
    this.serviceCliente.consultarClientes('').subscribe((clientes) => {
      console.log('clientes' + clientes);
      this.lstClientes = clientes;
      console.log(this.lstClientes);
      this.inicializarComponentesClie();
    });
  }
  guardarClienteE2E() {
      this.cliente.nombre = 'DC';
      this.cliente.telefono = '1234';
      this.cliente.direccion = 'CALLE 100';
      this.serviceCliente
        .guardarCliente(this.cliente)
        .subscribe((respuesta) => {
          console.log('respuesta' + respuesta);
        });
    
  }

  guardarCliente() {
    if (!this.validarCamposCliente()) {
      this.cliente.nombre =  this.obtenerClienteForm.pnombre.value;
      this.cliente.telefono = this.obtenerClienteForm.ptelefono.value;
      this.cliente.direccion = this.obtenerClienteForm.pdireccion.value;
      this.serviceCliente
        .guardarCliente(this.cliente)
        .subscribe((respuesta) => {
          console.log('respuesta' + respuesta);
          this.respuesta = respuesta;
          console.log(this.respuesta);
          this.hidePopupConf();
          this.openPopupRes();
          if (this.respuesta.tipoRespuesta == 'OK') {
            this.inicializarComponentesClie();
            this.getClientes();
          }
        });
    }
  }

  actualizarCliente() {
    if (!this.validarCamposClienteAct()) {
      this.cliente.id = this.idCliente;
      this.cliente.nombre = this.obtenerClienteActForm.pnombrea.value;
      this.cliente.telefono = this.obtenerClienteActForm.ptelefonoa.value;
      this.cliente.direccion = this.obtenerClienteActForm.pdirecciona.value;
      this.serviceCliente
        .actualizarCliente(this.cliente)
        .subscribe((respuesta) => {
          console.log('respuesta' + respuesta);
          this.respuesta = respuesta;
          console.log(this.respuesta);
          this.hidePopupActCli();
          this.openPopupRes();
          if (this.respuesta.tipoRespuesta == 'OK') {
            this.inicializarComponentesClie();
            this.getClientes();
          }
        });
    }
  }

  eliminarCliente() {
    this.serviceCliente
      .eliminarCliente(this.idCliente)
      .subscribe((respuesta) => {
        console.log('respuesta' + respuesta);
        this.respuesta = respuesta;
        console.log(this.respuesta);
        this.hidePopupConfEli();
        this.openPopupRes();
        if (this.respuesta.tipoRespuesta == 'OK') {
          this.getClientes();
        }
      });
  }

  validarCamposClienteAct(): boolean {
    this.message = '';
    this.indValidacion = false;
    if (
      this.obtenerClienteActForm.pnombrea.value == null ||
      this.obtenerClienteActForm.pnombrea.value === ''
    ) {
      this.message = 'Por favor ingresar nombre cliente';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerClienteActForm.ptelefonoa.value == null ||
      this.obtenerClienteActForm.ptelefonoa.value === ''
    ) {
      this.message = 'Por favor debe ingresar el telefono';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerClienteActForm.pdirecciona.value == null ||
      this.obtenerClienteActForm.pdirecciona.value === ''
    ) {
      this.message = 'Por favor debe ingresar la dirección';
      this.indValidacion = true;
    }

    return this.indValidacion;
  }

  validarCamposCliente(): boolean {
    this.message = '';
    this.indValidacion = false;
    if (
      this.obtenerClienteForm.pnombre.value == null ||
      this.obtenerClienteForm.pnombre.value === ''
    ) {
      this.message = 'Por favor ingresar nombre cliente';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerClienteForm.ptelefono.value == null ||
      this.obtenerClienteForm.ptelefono.value === ''
    ) {
      this.message = 'Por favor debe ingresar el telefono';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerClienteForm.pdireccion.value == null ||
      this.obtenerClienteForm.pdireccion.value === ''
    ) {
      this.message = 'Por favor debe ingresar la dirección';
      this.indValidacion = true;
    }

    return this.indValidacion;
  }

  hidePopupRes() {
    this.modalres = 'none';
  }
  openPopupRes() {
    this.modalres = 'block';
  }
  hidePopupConf() {
    this.modalconf = 'none';
  }
  openPopupConf() {
    if (!this.validarCamposCliente()) {
      this.modalconf = 'block';
    }
  }

  hidePopupConfEli() {
    this.modaleli = 'none';
  }
  openPopupConfEli(pos: number) {
    console.log('eliminando');
    this.idCliente = this.lstClientes[pos].id;
    this.modaleli = 'block';
  }

  hidePopupActCli() {
    this.modalactcl = 'none';
  }
  openPopupActCli(pos:number) {
    this.obtenerClienteActForm.pnombrea.setValue(this.lstClientes[pos].nombre);
    this.obtenerClienteActForm.ptelefonoa.setValue(this.lstClientes[pos].telefono);
    this.obtenerClienteActForm.pdirecciona.setValue(this.lstClientes[pos].direccion);
    this.idCliente = this.lstClientes[pos].id;
    this.modalactcl = 'block';
  }
}
