import { Component, OnInit } from '@angular/core';
import { ReporteService } from '../../services/reporte.service';
import { ClienteService } from '../../services/cliente.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Cliente } from 'src/app/domain/cliente';
import { Reporte } from 'src/app/domain/reporte';

@Component({
  selector: 'app-reporte',
  templateUrl: './reporte.component.html',
  styleUrls: ['./reporte.component.css']
})
export class ReporteComponent implements OnInit {

  lstDatosReportes: Reporte[] = [];
  lstClientes: Cliente[] = [];
  message: string;
  indValidacion: boolean ;
  fecInicio: String;
  fecFin: String;

  busquedaForm: FormGroup;

  constructor(private  serviceReport: ReporteService,
    private  serviceCliente: ClienteService,
    private fb: FormBuilder) { 
      this.message ='';
      this.indValidacion = false;
      this.fecInicio ='';
      this.fecFin ='';
      this.busquedaForm = this.inicializarComponentes();
      this.getClientes();
    }

  ngOnInit() {
    this.inicializarComponentes();
  }

  inicializarComponentes(){
    return this.busquedaForm = this.fb.group({
      fecInicio: new FormControl(),
      fecFin:  new FormControl(),
      idCliente:  new FormControl(),

    });
  }
  get obtenerBusquedaForm() { return this.busquedaForm.controls; }

  getClientes(){
    this.serviceCliente.consultarClientes('').subscribe(clientes => {
      console.log('clientes' + clientes);
      this.lstClientes = clientes;
      console.log(this.lstDatosReportes);
      this.inicializarComponentes();
    });
  }
  getDatosReporte() {
    if (!this.validarCampos()) {
        this.message = '';
        this.indValidacion = false;
        this.serviceReport.consultarDatosReporte(this.obtenerBusquedaForm.idCliente.value, this.obtenerBusquedaForm.fecInicio.value, this.obtenerBusquedaForm.fecFin.value).subscribe(datosReporte => {
          console.log('datosReporte' + datosReporte);
          this.lstDatosReportes = datosReporte;
          console.log(this.lstDatosReportes);
          this.inicializarComponentes();
        });
    }
  }

  validarCampos(): boolean {
    this.message = '';
    this.indValidacion = false;
    if (this.obtenerBusquedaForm.idCliente.value == null || this.obtenerBusquedaForm.idCliente.value === ''){
      this.message = 'Por favor debe cliente';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (this.obtenerBusquedaForm.fecInicio.value == null || this.obtenerBusquedaForm.fecInicio.value === ''){
      this.message = 'Por favor debe ingresar las fecha inicio';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if(this.obtenerBusquedaForm.fecFin.value == null || this.obtenerBusquedaForm.fecFin.value === ''){
       this.message = 'Por favor debe ingresar la fecha fin';
       this.indValidacion = true;
    }

    return this.indValidacion;
  }

}
