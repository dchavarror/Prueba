import { Component, OnInit } from '@angular/core';
import { ClienteService } from '../../services/cliente.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Cliente } from 'src/app/domain/cliente';
import { Cuenta } from 'src/app/domain/cuenta';
import { CuentaService } from '../../services/cuenta.service';
import { Movimiento } from 'src/app/domain/motivimiento';
import { Respuesta } from '../../domain/respuesta';
import { MovimientoService } from '../../services/movimiento.service';

@Component({
  selector: 'app-movimientos',
  templateUrl: './movimientos.component.html',
  styleUrls: ['./movimientos.component.css']
})
export class MovimientosComponent implements OnInit {

  lstClientes: Cliente[] = [];
  lstCuentas: Cuenta[] = [];
  message: string;
  indValidacion: boolean ;
  cuenta: Cuenta;
  movimiento: Movimiento;
  modalres = 'none';
  modalconf = 'none';
  respuesta : Respuesta;

  movimientoForm: FormGroup;

  constructor(private  serviceCuenta: CuentaService,
    private  serviceCliente: ClienteService,
    private serviceMovimiento: MovimientoService,
    private fb: FormBuilder) { 
      this.message ='';
      this.indValidacion = false;
      this.movimiento = new Movimiento();
      this.cuenta = new Cuenta();
      this.respuesta = new Respuesta();
      this.movimientoForm = this.inicializarComponentes();
      this.getClientes();
    }

  ngOnInit() {
  }

  inicializarComponentes(){
    return this.movimientoForm = this.fb.group({
      idCuenta: new FormControl(),
      idTipMov:  new FormControl(),
      idCliente:  new FormControl(),
      vmovimiento:  new FormControl(),

    });
  }
  get obtenerMovimientoForm() { return this.movimientoForm.controls; }

  getClientes(){
    this.serviceCliente.consultarClientes('').subscribe(clientes => {
      console.log('clientes' + clientes);
      this.lstClientes = clientes;
      console.log(this.lstClientes);
      this.inicializarComponentes();
    });
  }
  onChangeCliente(){
    this.cuenta.idCliente = this.obtenerMovimientoForm.idCliente.value;
    
    this.serviceCuenta.consultarCuentas(this.cuenta.idCliente).subscribe(cuentas => {
      console.log('cuentas' + cuentas);
      this.lstCuentas = cuentas;
      console.log(this.lstCuentas);
    });
  }

  guardarMovimiento(){
    if(!this.validarCampos()){
      this.movimiento.idCuenta = this.obtenerMovimientoForm.idCuenta.value;
      this.movimiento.idTipo = this.obtenerMovimientoForm.idTipMov.value;
      this.movimiento.valor = this.obtenerMovimientoForm.vmovimiento.value;

      this.serviceMovimiento
      .guardarMovimiento(this.movimiento)
      .subscribe((respuesta) => {
        console.log('respuesta' + respuesta);
        this.respuesta = respuesta;
        console.log(this.respuesta);
        this.hidePopupConf();
        this.openPopupRes();
        if (this.respuesta.tipoRespuesta == 'OK') {
          this.inicializarComponentes();
        }
      });
    }
  }

  validarCampos(): boolean {
    this.message = '';
    this.indValidacion = false;
    if (this.obtenerMovimientoForm.idCliente.value == null || this.obtenerMovimientoForm.idCliente.value === ''){
      this.message = 'Por favor debe seleccionar cliente';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (this.obtenerMovimientoForm.idCuenta.value == null || this.obtenerMovimientoForm.idCuenta.value === ''){
      this.message = 'Por debe seleccionar la cuenta';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if(this.obtenerMovimientoForm.idTipMov.value == null || this.obtenerMovimientoForm.idTipMov.value === ''){
       this.message = 'Por favor seleccionar tipo novedad';
       this.indValidacion = true;
    }
    if(this.obtenerMovimientoForm.vmovimiento.value == null || this.obtenerMovimientoForm.vmovimiento.value === ''){
      this.message = 'Por ingrese el valor movimiento';
      this.indValidacion = true;
   }

    return this.indValidacion;
  }

  hidePopupRes() {
    this.modalres = 'none';
  }
  openPopupRes() {
    this.modalres = 'block';
  }
  hidePopupConf() {
    this.modalconf = 'none';
  }
  openPopupConf() {
    if (!this.validarCampos()) {
      this.modalconf = 'block';
    }
  }

}
