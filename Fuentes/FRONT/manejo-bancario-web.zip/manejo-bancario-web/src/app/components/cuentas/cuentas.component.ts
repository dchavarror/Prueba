import { Component, OnInit } from '@angular/core';
import { ReporteService } from '../../services/reporte.service';
import { ClienteService } from '../../services/cliente.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Cliente } from 'src/app/domain/cliente';
import { Cuenta } from '../../domain/cuenta';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { CuentaService } from '../../services/cuenta.service';
import { Respuesta } from '../../domain/respuesta';

@Component({
  selector: 'app-cuentas',
  templateUrl: './cuentas.component.html',
  styleUrls: ['./cuentas.component.css']
})
export class CuentasComponent implements OnInit {

  lstCuentas: Cuenta[] = [];
  lstClientes: Cliente[] = [];
  message: string;
  indValidacion: boolean ;
  cuenta: Cuenta;
  respuesta: Respuesta;

  cuentaForm: FormGroup;
  actCuentaForm: FormGroup;
  modalres = 'none';
  modalconf = 'none';
  modalactcu = 'none';
  modaleli = 'none';
  idCuenta = 0;

  constructor(private  serviceCuenta: CuentaService,
    private  serviceCliente: ClienteService,
    private fb: FormBuilder) { 
      this.message ='';
      this.indValidacion = false;
      this.cuentaForm = this.inicializarComponentesCuenta();
      this.actCuentaForm = this.inicializarComponentesActCuenta();
      this.getClientes();
      this.cuenta = new Cuenta();
      this.respuesta = new Respuesta();
    }

  ngOnInit() {
  }

  inicializarComponentesCuenta(){
    return this.cuentaForm = this.fb.group({
      idCliente: new FormControl(),
      numero:  new FormControl(),
      saldo:  new FormControl(),

    });
  }

  inicializarComponentesActCuenta(){
    return this.actCuentaForm = this.fb.group({
      idClientea: new FormControl(),
      numeroa:  new FormControl(),
      saldoa:  new FormControl(),

    });
  }
  
  get obtenerCuentaForm() { return this.cuentaForm.controls; }
  get obtenerActCuentaForm() { return this.actCuentaForm.controls; }

  getClientes(){
    this.serviceCliente.consultarClientes('').subscribe(clientes => {
      console.log('clientes' + clientes);
      this.lstClientes = clientes;
      console.log(this.lstClientes);
    });
  }

  onChangeCliente(){
    this.cuenta.idCliente = this.obtenerCuentaForm.idCliente.value;
    
    this.serviceCuenta.consultarCuentas(this.cuenta.idCliente).subscribe(cuentas => {
      console.log('cuentas' + cuentas);
      this.lstCuentas = cuentas;
      console.log(this.lstCuentas);
    });
  }

  consultarCuentas(){
    console.log("id cliente " + this.cuenta.idCliente);
    
    this.serviceCuenta.consultarCuentas(this.cuenta.idCliente).subscribe(cuentas => {
      console.log('cuentas' + cuentas);
      this.lstCuentas = cuentas;
      console.log(this.lstCuentas);
    });
  }
  
  guardarCuenta() {
    if (!this.validarCamposCuenta()) {
      this.cuenta.idCliente = this.obtenerCuentaForm.idCliente.value;
      this.cuenta.numero = this.obtenerCuentaForm.numero.value;
      this.cuenta.saldo = this.obtenerCuentaForm.saldo.value;
      this.serviceCuenta
        .guardarCuenta(this.cuenta)
        .subscribe((respuesta) => {
          console.log('respuesta' + respuesta);
          this.respuesta = respuesta;
          console.log(this.respuesta);
          this.hidePopupConf();
          this.openPopupRes();
          if (this.respuesta.tipoRespuesta == 'OK') {
            this.consultarCuentas();
            this.inicializarComponentesCuenta();
          }
        });
    }
  }

  actualizarCuenta() {
    if (!this.validarCamposCuentaAct()) {
      this.cuenta.id = this.idCuenta;
      this.cuenta.numero = this.obtenerActCuentaForm.numeroa.value;
      this.cuenta.saldo = this.obtenerActCuentaForm.saldoa.value;
      this.serviceCuenta
        .actualizarCuenta(this.cuenta)
        .subscribe((respuesta) => {
          console.log('respuesta' + respuesta);
          this.respuesta = respuesta;
          console.log(this.respuesta);
          this.hidePopupActCuen();
          this.openPopupRes();
          if (this.respuesta.tipoRespuesta == 'OK') {
            this.consultarCuentas();
            this.inicializarComponentesActCuenta();
            
          }
        });
    }
  }

  eliminarCuenta() {
    this.serviceCuenta
      .eliminarCuenta(this.idCuenta)
      .subscribe((respuesta) => {
        console.log('respuesta' + respuesta);
        this.respuesta = respuesta;
        console.log(this.respuesta);
        this.hidePopupConfEli();
        this.openPopupRes();
        if (this.respuesta.tipoRespuesta == 'OK') {
            this.consultarCuentas();
        }
      });
  }

  validarCamposCuentaAct(): boolean {
    this.message = '';
    this.indValidacion = false;
    if (
      this.obtenerActCuentaForm.numeroa.value == null ||
      this.obtenerActCuentaForm.numeroa.value === ''
    ) {
      this.message = 'Por favor debe ingresar el numero de cuenta';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerActCuentaForm.saldoa.value == null ||
      this.obtenerActCuentaForm.saldoa.value === ''
    ) {
      this.message = 'Por favor debe ingresar el saldo de la cuenta';
      this.indValidacion = true;
    }

    return this.indValidacion;
  }

  validarCamposCuenta(): boolean {
    this.message = '';
    this.indValidacion = false;
    if (
      this.obtenerCuentaForm.idCliente.value == null ||
      this.obtenerCuentaForm.idCliente.value === ''
    ) {
      this.message = 'Por favor seleccionar cliente';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerCuentaForm.numero.value == null ||
      this.obtenerCuentaForm.numero.value === ''
    ) {
      this.message = 'Por favor debe ingresar el numero de cuenta';
      this.indValidacion = true;
      return this.indValidacion;
    }
    if (
      this.obtenerCuentaForm.saldo.value == null ||
      this.obtenerCuentaForm.saldo.value === ''
    ) {
      this.message = 'Por favor debe ingresar el saldo de cuenta';
      this.indValidacion = true;
    }

    return this.indValidacion;
  }

  hidePopupRes() {
    this.modalres = 'none';
  }
  openPopupRes() {
    this.modalres = 'block';
  }
  hidePopupConf() {
    this.modalconf = 'none';
  }
  openPopupConf() {
    if (!this.validarCamposCuenta()) {
      this.modalconf = 'block';
    }
  }

  hidePopupConfEli() {
    this.modaleli = 'none';
  }
  openPopupConfEli(pos: number) {
    console.log('eliminando');
    this.idCuenta = this.lstCuentas[pos].id;
    this.modaleli = 'block';
  }

  hidePopupActCuen() {
    this.modalactcu = 'none';
  }
  openPopupActCuen(pos:number) {
    this.obtenerActCuentaForm.idClientea.setValue(this.lstCuentas[pos].idCliente);
    this.obtenerActCuentaForm.numeroa.setValue(this.lstCuentas[pos].numero);
    this.obtenerActCuentaForm.saldoa.setValue(this.lstCuentas[pos].saldo);
    this.idCuenta = this.lstCuentas[pos].id;
    this.modalactcu = 'block';
  }

}
