import { Routes } from '@angular/router';
import { ClienteComponent } from './components/cliente/cliente.component';
import { Movimiento } from './domain/motivimiento';
import { MovimientosComponent } from './components/movimientos/movimientos.component';
import { ReporteComponent } from './components/reporte/reporte.component';
import { CuentasComponent } from './components/cuentas/cuentas.component';



export const ROUTES: Routes = [
    { path: 'cliente', component: ClienteComponent },
    { path: 'cuentas', component: CuentasComponent },
    { path: 'movimientos', component: MovimientosComponent },
    { path: 'reporte', component: ReporteComponent },
    { path: '', pathMatch: 'full', redirectTo: 'cliente' },
    { path: '**', pathMatch: 'full', redirectTo: 'cliente' }
];

