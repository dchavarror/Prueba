
export class Cliente {
    id = 0;
    nombre = '';
    telefono = '';
    direccion = '';
}