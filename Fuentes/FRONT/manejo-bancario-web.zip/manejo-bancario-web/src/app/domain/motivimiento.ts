export class Movimiento {
    id = 0;
    idTipo = 0;
    valor = 0;
    idCuenta = 0;
}