export class Cuenta {
    id = 0;
    numero = 0;
    saldo = 0;
    idCliente = 0;
}