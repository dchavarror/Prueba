
export class Respuesta {
    tipoRespuesta = '';
    objeto = {};
    descripcion = '';
}