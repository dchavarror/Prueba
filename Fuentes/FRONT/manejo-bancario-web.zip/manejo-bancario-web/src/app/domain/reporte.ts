export class Reporte {
    nombre = '';
    valor = 0;
    numero = 0;
    saldo = 0;
    descTipoMov = '';
    fecha = '';
}