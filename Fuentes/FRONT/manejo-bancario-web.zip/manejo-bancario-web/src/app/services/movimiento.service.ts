import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { ServiceUtils } from './services.utils';
import { Movimiento } from 'src/app/domain/motivimiento';

@Injectable({
  providedIn: 'root',
})
export class MovimientoService {
  endPointGuardarMovimiento = '/movimiento/guardarMovimiento';
  constructor(private servicio: ServiceUtils) {}
 
  guardarMovimiento(movimiento: Movimiento) {
    return this.servicio
      .post(this.endPointGuardarMovimiento, movimiento)
      .pipe(map((data) => data));
  }

 
}
