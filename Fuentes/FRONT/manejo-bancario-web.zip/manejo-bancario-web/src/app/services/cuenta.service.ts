import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ServiceUtils } from './services.utils';
import { Cliente } from '../domain/cliente';
import { Cuenta } from '../domain/cuenta';

@Injectable({
  providedIn: 'root',
})
export class CuentaService {
  endPointConsCuentas = '/cuenta/consultarCuentas';
  endPointGuardarCuenta = '/cuenta/guardarCuenta';
  endPointActualizarCuenta = '/cuenta/actualizarCuenta';
  endPointEliminarCuenta = '/cuenta/eliminarCuenta';

  constructor(private servicio: ServiceUtils) {}
  consultarCuentas(idCliente: Number) {
    let query = '';
    if (idCliente != null) {
       query = '?idCliente=' + idCliente;
    }

    return this.servicio
      .get(this.endPointConsCuentas, query)
      .pipe(map((data) => data.objeto));
  }

  guardarCuenta(cuenta: Cuenta) {
    return this.servicio
      .post(this.endPointGuardarCuenta, cuenta)
      .pipe(map((data) => data));
  }

  actualizarCuenta(cuenta: Cuenta) {
    return this.servicio
      .put(this.endPointActualizarCuenta, cuenta)
      .pipe(map((data) => data));
  }
  eliminarCuenta(idCuenta: Number) {
    let query = '?idCuenta=' + idCuenta;
    return this.servicio
      .delete(this.endPointEliminarCuenta, query)
      .pipe(map((data) => data));
  }
}
