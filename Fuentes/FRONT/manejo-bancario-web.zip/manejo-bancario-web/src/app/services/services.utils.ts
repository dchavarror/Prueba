import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpHeaderResponse } from '@angular/common/http';
import { concat, Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServiceUtils {
  constructor(private http: HttpClient) { }
 
  public post(endpoint: string, payload = {}): Observable<any> {
    console.log(payload);
    return this.http.post(environment.apiUrl  + endpoint, payload, {  });
  }

  public get(endpoint: string, query: string): Observable<any> {
    const endpointFinal = endpoint + query;
    console.log('url  ' + environment.apiUrl  + endpointFinal);
    console.log('url get ' + endpointFinal);
    return this.http.get(environment.apiUrl  + endpointFinal, { });
  }

  public put(endpoint: string, payload = {}): Observable<any> {
    console.log(payload);
    return this.http.put(environment.apiUrl  + endpoint, payload, {  });
  }
  public delete(endpoint: string, query: string): Observable<any> {
    const endpointFinal = endpoint + query;
    console.log('url  ' + environment.apiUrl  + endpointFinal);
    console.log('url delete ' + endpointFinal);
    return this.http.delete(environment.apiUrl  + endpointFinal, { });
  }

}
