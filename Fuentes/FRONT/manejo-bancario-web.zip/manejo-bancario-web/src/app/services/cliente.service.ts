import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ServiceUtils } from './services.utils';
import { Cliente } from '../domain/cliente';

@Injectable({
  providedIn: 'root',
})
export class ClienteService {
  endPointConsClientes = '/cliente/consultarClientes';
  endPointGuardarCliente = '/cliente/guardarCliente';
  endPointActualizarCliente = '/cliente/actualizarCliente';
  endPointEliminarCliente = '/cliente/eliminarCliente';

  constructor(private servicio: ServiceUtils) {}
  consultarClientes(nombre: String) {
    let query = '';
    if (nombre != '') {
      query = '?nombre=' + nombre;
    }

    return this.servicio
      .get(this.endPointConsClientes, query)
      .pipe(map((data) => data.objeto));
  }

  guardarCliente(cliente: Cliente) {
    return this.servicio
      .post(this.endPointGuardarCliente, cliente)
      .pipe(map((data) => data));
  }

  actualizarCliente(cliente: Cliente) {
    return this.servicio
      .put(this.endPointActualizarCliente, cliente)
      .pipe(map((data) => data));
  }
  eliminarCliente(idCliente: Number) {
    let query = '?idCliente=' + idCliente;
    return this.servicio
      .delete(this.endPointEliminarCliente, query)
      .pipe(map((data) => data));
  }
}
