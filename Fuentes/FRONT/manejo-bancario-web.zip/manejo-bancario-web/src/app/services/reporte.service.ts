import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ServiceUtils } from './services.utils';

@Injectable({
  providedIn: 'root'
})
export class ReporteService {
  endPointConsDatRepor = '/reporte/consultarDatosReporte';

  constructor(private servicio: ServiceUtils) { }
    consultarDatosReporte(idCliente: Number,  fecInicio: String, fecFin: String ) {
      const query = '?idCliente=' + idCliente + '&fecInicio=' + fecInicio + '&fecFin=' +fecFin ;
      return this.servicio.get(this.endPointConsDatRepor , query).pipe( map( data => data.objeto ));
    }

}
