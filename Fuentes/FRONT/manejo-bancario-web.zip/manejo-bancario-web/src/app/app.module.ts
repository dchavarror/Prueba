import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReporteComponent } from './components/reporte/reporte.component';
import { ClienteComponent } from './components/cliente/cliente.component';
import { MovimientosComponent } from './components/movimientos/movimientos.component';
import { CuentasComponent } from './components/cuentas/cuentas.component';
import { Cliente } from './domain/cliente';
import { Cuenta } from './domain/cuenta';
import { Movimiento } from './domain/motivimiento';
import { Respuesta } from '../../../co-tmo-webapp/src/app/domain/respuesta';
import { Reporte } from 'src/app/domain/reporte';
import { NavbarComponent } from './components/shared/navbar/navbar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ROUTES } from './app.routes';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ReporteComponent,
    ClienteComponent,
    MovimientosComponent,
    CuentasComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(ROUTES, { useHash: true, relativeLinkResolution: 'legacy' })
  ],
  providers: [Cliente, Cuenta, Movimiento, Reporte, Respuesta],
  bootstrap: [AppComponent]
})
export class AppModule { }
