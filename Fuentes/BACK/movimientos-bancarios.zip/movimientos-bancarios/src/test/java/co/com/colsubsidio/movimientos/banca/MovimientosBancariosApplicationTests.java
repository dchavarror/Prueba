package co.com.colsubsidio.movimientos.banca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovimientosBancariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
