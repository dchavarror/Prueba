package co.com.colsubsidio.movimientos.banca.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.ICuenta;
import co.com.colsubsidio.movimientos.banca.dto.CuentaDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.utils.Conexion;

@Component
public class CuentaDAO implements ICuenta {

	@Autowired
	@Qualifier("jdbcPruebaBanca")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public RespuestaDTO guardarCuenta(CuentaDTO cuenta) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_guardar_cuenta(?,?,?,?,?,?) }");
			callableStatement.setInt(1, cuenta.getIdCliente() != null ? cuenta.getIdCliente() : null);
			callableStatement.setInt(2, cuenta.getNumero() != null ? cuenta.getNumero() :null);
			callableStatement.setDouble(3, cuenta.getSaldo()!= null ? cuenta.getSaldo() :null );
			
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(4));
			respuesta.setDescripcion(callableStatement.getString(6));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

	@Override
	public RespuestaDTO actualizarCuenta(CuentaDTO cuenta) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_actualizar_cuenta(?,?,?,?,?,?) }");
			callableStatement.setInt(1, cuenta.getId() != null ? cuenta.getId() : null);
			callableStatement.setInt(2, cuenta.getNumero() != null ? cuenta.getNumero() :null);
			callableStatement.setDouble(3, cuenta.getSaldo()!= null ? cuenta.getSaldo() :null );
			
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(4));
			respuesta.setDescripcion(callableStatement.getString(6));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

	@Override
	public RespuestaDTO eliminarCuenta(Integer idCuenta) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_eliminar_cuenta(?,?,?,?) }");
			callableStatement.setInt(1,  idCuenta != null ? idCuenta :null);
			
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(2));
			respuesta.setDescripcion(callableStatement.getString(4));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

	@Override
	public RespuestaDTO consultarCuentas(Integer idCliente) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			System.out.println("idCliente " + idCliente);
			conn = jdbcTemplate.getDataSource().getConnection();
			conn.setAutoCommit(false);
			callableStatement = conn.prepareCall("{ call public.fn_consultar_cuentas(?,?,?,?,?) }");
			callableStatement.setInt(1, idCliente != null ? idCliente :null);
			
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5,  Types.REF_CURSOR);
			callableStatement.execute();
			
			
			
			respuesta.setTipoRespuesta(callableStatement.getString(2));
			respuesta.setDescripcion(callableStatement.getString(4));
			
			ResultSet results = (ResultSet) callableStatement.getObject(5);
			
			if(results != null) {
				List<CuentaDTO> lstCuentas = new ArrayList<CuentaDTO>();
				while (results.next()) {
					CuentaDTO itemCuenta = new CuentaDTO();
					itemCuenta.setId(results.getInt(1));
					itemCuenta.setNumero(results.getInt(2));
					itemCuenta.setSaldo(results.getDouble(3));
					lstCuentas.add(itemCuenta);
				}
				respuesta.setObjeto(lstCuentas);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

}
