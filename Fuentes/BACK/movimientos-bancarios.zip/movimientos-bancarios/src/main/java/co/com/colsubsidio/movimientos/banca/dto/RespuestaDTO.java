package co.com.colsubsidio.movimientos.banca.dto;

public class RespuestaDTO {

	private String tipoRespuesta;
	private Object objeto;
	private String descripcion;
	
	
	public RespuestaDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getTipoRespuesta() {
		return tipoRespuesta;
	}
	public void setTipoRespuesta(String tipoRespuesta) {
		this.tipoRespuesta = tipoRespuesta;
	}
	public Object getObjeto() {
		return objeto;
	}
	public void setObjeto(Object objeto) {
		this.objeto = objeto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
