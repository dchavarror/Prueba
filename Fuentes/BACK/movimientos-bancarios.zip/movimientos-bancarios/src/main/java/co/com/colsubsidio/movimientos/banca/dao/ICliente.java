package co.com.colsubsidio.movimientos.banca.dao;

import co.com.colsubsidio.movimientos.banca.dto.ClienteDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;

public interface ICliente {

	public RespuestaDTO guardarCliente(final ClienteDTO cliente);
	
	public RespuestaDTO actualizarCliente(final ClienteDTO cliente);
	
	public RespuestaDTO eliminarCliente(final Integer idCliente);
	
	public RespuestaDTO consultarClientes(final String nombre);
	
}
