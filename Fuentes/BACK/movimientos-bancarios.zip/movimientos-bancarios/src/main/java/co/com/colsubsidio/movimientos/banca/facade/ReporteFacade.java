package co.com.colsubsidio.movimientos.banca.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.IReporte;

@Component
public class ReporteFacade {

	@Autowired
	private IReporte reporte;

	public IReporte getReporte() {
		return reporte;
	}
	
}
