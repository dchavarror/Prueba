package co.com.colsubsidio.movimientos.banca.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.colsubsidio.movimientos.banca.dto.MovimientoDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.facade.MovimientoFacade;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/movimiento/")
public class MovimientoService {

	@Autowired
	private MovimientoFacade movimientoFacade;
	
	@RequestMapping(value = "guardarMovimiento", method = RequestMethod.POST)
	public ResponseEntity<RespuestaDTO> guardarMovimiento(
			 @RequestBody MovimientoDTO movimiento) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = movimientoFacade.getMovimiento().guardarMovimiento(movimiento);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.CREATED);
	}
}
