package co.com.colsubsidio.movimientos.banca.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.IMovimiento;
import co.com.colsubsidio.movimientos.banca.dto.MovimientoDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.utils.Conexion;

@Component
public class MovimientoDAO implements IMovimiento {

	@Autowired
	@Qualifier("jdbcPruebaBanca")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public RespuestaDTO guardarMovimiento(MovimientoDTO movimiento) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_guardar_movimiento(?,?,?,?,?,?) }");
			callableStatement.setInt(1, movimiento.getIdCuenta() != null ?  movimiento.getIdCuenta() : null);
			callableStatement.setDouble(2, movimiento.getValor() != null ? movimiento.getValor() :null);
			callableStatement.setInt(3, movimiento.getIdTipo()!= null ?  movimiento.getIdTipo() :null );
			
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(4));
			respuesta.setDescripcion(callableStatement.getString(6));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}
}
