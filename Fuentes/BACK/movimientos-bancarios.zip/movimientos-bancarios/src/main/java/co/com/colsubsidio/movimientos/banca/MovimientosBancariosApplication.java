package co.com.colsubsidio.movimientos.banca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovimientosBancariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovimientosBancariosApplication.class, args);
	}

}
