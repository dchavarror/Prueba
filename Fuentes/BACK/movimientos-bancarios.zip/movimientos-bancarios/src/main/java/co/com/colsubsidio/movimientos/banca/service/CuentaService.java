package co.com.colsubsidio.movimientos.banca.service;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.colsubsidio.movimientos.banca.dto.CuentaDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.facade.CuentaFacade;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cuenta/")
public class CuentaService {

	@Autowired
	private CuentaFacade cuentaFacade;
	
	
	@RequestMapping(value = "consultarCuentas", method = RequestMethod.GET)
	public ResponseEntity<RespuestaDTO> consultarCuentas(
			@PathParam("idCliente") Integer idCliente) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = cuentaFacade.getCuenta().consultarCuentas(idCliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
	
	@RequestMapping(value = "guardarCuenta", method = RequestMethod.POST)
	public ResponseEntity<RespuestaDTO> guardarCuenta(
			 @RequestBody CuentaDTO cuenta) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = cuentaFacade.getCuenta().guardarCuenta(cuenta);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.CREATED);
	}
	@RequestMapping(value = "actualizarCuenta", method = RequestMethod.PUT)
	public ResponseEntity<RespuestaDTO> actualizarCuenta(
			 @RequestBody CuentaDTO cuenta) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = cuentaFacade.getCuenta().actualizarCuenta(cuenta);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
	
	@RequestMapping(value = "eliminarCuenta", method = RequestMethod.DELETE)
	public ResponseEntity<RespuestaDTO> eliminarCuenta(
			@PathParam("idCuenta") Integer idCuenta) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = cuentaFacade.getCuenta().eliminarCuenta(idCuenta);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
}
