package co.com.colsubsidio.movimientos.banca.dao;

import java.util.Date;

import co.com.colsubsidio.movimientos.banca.dto.MovimientoDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;

public interface IMovimiento {
	
	public RespuestaDTO guardarMovimiento(final MovimientoDTO movimiento);
	
}
