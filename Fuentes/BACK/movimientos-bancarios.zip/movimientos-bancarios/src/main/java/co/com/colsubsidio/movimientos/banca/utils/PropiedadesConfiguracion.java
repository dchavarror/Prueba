package co.com.colsubsidio.movimientos.banca.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class PropiedadesConfiguracion {

	@Autowired
	private Environment env;
	
	public String getPropiedad(final String llave) {
		try {
			String valorPropiedad = env.getProperty(llave);
			if (valorPropiedad != null && !valorPropiedad.isEmpty()) {
				return valorPropiedad;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
