package co.com.colsubsidio.movimientos.banca.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.IReporte;
import co.com.colsubsidio.movimientos.banca.dto.ReporteDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.utils.Conexion;

@Component
public class ReporteDAO implements IReporte {

	@Autowired
	@Qualifier("jdbcPruebaBanca")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public RespuestaDTO consultarDatosReporte(Integer idCliente, String fecInicio, String fecFin) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			System.out.println("idCliente " + idCliente);
			System.out.println("fecInicio " + fecInicio);
			System.out.println("fecFin " + fecFin);
			conn = jdbcTemplate.getDataSource().getConnection();
			conn.setAutoCommit(false);
			callableStatement = conn.prepareCall("{ call public.fn_consultar_movimientos(?,?,?,?,?,?,?) }");
			callableStatement.setInt(1, idCliente != null ? idCliente :null);
			callableStatement.setString(2, fecInicio != null ? fecInicio :null);
			callableStatement.setString(3, fecFin != null ? fecFin :null);
			
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7,  Types.REF_CURSOR);
			callableStatement.execute();
			
			
			respuesta.setTipoRespuesta(callableStatement.getString(5));
			respuesta.setDescripcion(callableStatement.getString(6));
			
			ResultSet results = (ResultSet) callableStatement.getObject(7);
			
			if(results != null) {
				List<ReporteDTO> lstReportes = new ArrayList<ReporteDTO>();
				while (results.next()) {
					ReporteDTO itemReporte = new ReporteDTO();
					itemReporte.setDescTipoMov(results.getString(1));
					itemReporte.setFecha(results.getString(2));
					
					itemReporte.setValor(results.getDouble(3));
					itemReporte.setNumero(results.getInt(4));
					itemReporte.setSaldo(results.getDouble(5));
					itemReporte.setNombre(results.getString(6));
					lstReportes.add(itemReporte);
				}
				respuesta.setObjeto(lstReportes);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

}
