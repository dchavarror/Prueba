package co.com.colsubsidio.movimientos.banca.dto;

public class ReporteDTO {

	private String nombre;
	private Double valor;
	private Integer numero;
	private Double saldo;
	private String descTipoMov;
	private String fecha;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public String getDescTipoMov() {
		return descTipoMov;
	}

	public void setDescTipoMov(String descTipoMov) {
		this.descTipoMov = descTipoMov;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

}
