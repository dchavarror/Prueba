package co.com.colsubsidio.movimientos.banca.service;


import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.colsubsidio.movimientos.banca.dto.ClienteDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.facade.ClienteFacade;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cliente/")
public class ClienteService {

	@Autowired
	private ClienteFacade clienteFacade;
	
	
	@RequestMapping(value = "consultarClientes", method = RequestMethod.GET)
	public ResponseEntity<RespuestaDTO> consultarClientes(
			@PathParam("nombre") String nombre) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = clienteFacade.getCliente().consultarClientes(nombre);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
	
	@RequestMapping(value = "guardarCliente", method = RequestMethod.POST)
	public ResponseEntity<RespuestaDTO> guardarCliente(
			 @RequestBody ClienteDTO cliente) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = clienteFacade.getCliente().guardarCliente(cliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.CREATED);
	}
	@RequestMapping(value = "actualizarCliente", method = RequestMethod.PUT)
	public ResponseEntity<RespuestaDTO> actualizarCliente(
			 @RequestBody ClienteDTO cliente) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = clienteFacade.getCliente().actualizarCliente(cliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
	
	@RequestMapping(value = "eliminarCliente", method = RequestMethod.DELETE)
	public ResponseEntity<RespuestaDTO> eliminarCliente(
			@PathParam("idCliente") Integer idCliente) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = clienteFacade.getCliente().eliminarCliente(idCliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
	
}
