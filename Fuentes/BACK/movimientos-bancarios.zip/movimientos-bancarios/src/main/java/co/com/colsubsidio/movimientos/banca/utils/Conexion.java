package co.com.colsubsidio.movimientos.banca.utils;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
@ConfigurationProperties
public class Conexion {

	
	@Autowired
	private PropiedadesConfiguracion propiedades;
	

	@Autowired
	private DataSourceProperties dataSourceProperties;

	@Autowired
	private DataSource dataSource;

	public DataSourceProperties dataSourceProperties() {
		try {
			this.dataSourceProperties.setUrl(this.propiedades.getPropiedad("url"));
			this.dataSourceProperties.setUsername(this.propiedades.getPropiedad("usuario"));
			this.dataSourceProperties.setPassword(this.propiedades.getPropiedad("contrasenia"));
			this.dataSourceProperties.setDriverClassName(this.propiedades.getPropiedad("driver-class-name"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.dataSourceProperties;
	}

	@Bean(name = "dsPruebaBanca")
	public DataSource dataSource() {
		try {
			dataSourceProperties();
			this.dataSource = this.dataSourceProperties.initializeDataSourceBuilder().build();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.dataSource;
	}

	@Bean(name = "jdbcPruebaBanca")
	@Autowired
	public JdbcTemplate masterJdbcTemplate(@Qualifier("dsPruebaBanca") DataSource dsMaster) {
		
		return new JdbcTemplate(dsMaster);

	}
	
	public static void cerrarConexion(Connection conn) {
		try {
			if(conn != null) {
			   conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
