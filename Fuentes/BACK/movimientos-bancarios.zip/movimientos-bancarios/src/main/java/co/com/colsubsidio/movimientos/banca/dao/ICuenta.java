package co.com.colsubsidio.movimientos.banca.dao;

import co.com.colsubsidio.movimientos.banca.dto.CuentaDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;

public interface ICuenta {

	public RespuestaDTO guardarCuenta(final CuentaDTO cuenta);

	public RespuestaDTO actualizarCuenta(final CuentaDTO cuenta);

	public RespuestaDTO eliminarCuenta(final Integer idCuenta);

	public RespuestaDTO consultarCuentas(final Integer idCliente);

}
