package co.com.colsubsidio.movimientos.banca.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.ICliente;

@Component
public class ClienteFacade {

	@Autowired
	private ICliente cliente;

	public ICliente getCliente() {
		return cliente;
	}
	
}
