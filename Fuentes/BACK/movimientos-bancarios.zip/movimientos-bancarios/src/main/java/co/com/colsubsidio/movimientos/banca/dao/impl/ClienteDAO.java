package co.com.colsubsidio.movimientos.banca.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.ICliente;
import co.com.colsubsidio.movimientos.banca.dto.ClienteDTO;
import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.utils.Conexion;

@Component
public class ClienteDAO implements ICliente{

	@Autowired
	@Qualifier("jdbcPruebaBanca")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public RespuestaDTO guardarCliente(ClienteDTO cliente) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_crear_cliente(?,?,?,?,?,?) }");
			callableStatement.setString(1, cliente.getNombre() != null ? cliente.getNombre() :"");
			callableStatement.setString(2, cliente.getTelefono() != null ? cliente.getTelefono() :"");
			callableStatement.setString(3, cliente.getDireccion() != null ? cliente.getDireccion() :"");
			
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(4));
			respuesta.setDescripcion(callableStatement.getString(6));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

	@Override
	public RespuestaDTO actualizarCliente(ClienteDTO cliente) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_actualizar_cliente(?,?,?,?,?,?,?) }");
			callableStatement.setString(1, cliente.getNombre() != null ? cliente.getNombre() :"");
			callableStatement.setString(2, cliente.getTelefono() != null ? cliente.getTelefono() :"");
			callableStatement.setString(3, cliente.getDireccion() != null ? cliente.getDireccion() :"");
			callableStatement.setInt(4,  cliente.getId() != null ? cliente.getId() :null);
			
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(5));
			respuesta.setDescripcion(callableStatement.getString(7));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

	@Override
	public RespuestaDTO eliminarCliente(Integer idCliente) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		    conn.setAutoCommit(true);
			callableStatement = conn.prepareCall("{ call public.fn_eliminar_cliente(?,?,?,?) }");
			callableStatement.setInt(1,  idCliente != null ? idCliente :null);
			
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.execute();
			
			respuesta.setTipoRespuesta(callableStatement.getString(2));
			respuesta.setDescripcion(callableStatement.getString(4));
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}

	@Override
	public RespuestaDTO consultarClientes(String nombre) {
		Connection conn = null;
		CallableStatement callableStatement = null;
		RespuestaDTO respuesta = new RespuestaDTO();
		
		try {
			System.out.println("nombre cliente " + nombre);
			conn = jdbcTemplate.getDataSource().getConnection();
			conn.setAutoCommit(false);
			callableStatement = conn.prepareCall("{ call public.fn_consultar_clientes(?,?,?,?,?) }");
			callableStatement.setString(1, nombre != null ? "%"+ nombre + "%" :"");
			
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5,  Types.REF_CURSOR);
			callableStatement.execute();
			
			
			
			respuesta.setTipoRespuesta(callableStatement.getString(2));
			respuesta.setDescripcion(callableStatement.getString(4));
			
			ResultSet results = (ResultSet) callableStatement.getObject(5);
			
			if(results != null) {
				List<ClienteDTO> lstClientes = new ArrayList<ClienteDTO>();
				while (results.next()) {
					ClienteDTO itemCliente = new ClienteDTO();
					itemCliente.setId(results.getInt(1));
					itemCliente.setNombre(results.getString(2));
					itemCliente.setTelefono(results.getString(3));
					itemCliente.setDireccion(results.getString(4));
					lstClientes.add(itemCliente);
				}
				respuesta.setObjeto(lstClientes);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			Conexion.cerrarConexion(conn);
		}
		
		return respuesta;
	}
	
	

}
