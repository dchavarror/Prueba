package co.com.colsubsidio.movimientos.banca.service;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;
import co.com.colsubsidio.movimientos.banca.facade.ReporteFacade;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/reporte/")
public class ReporteService {

	@Autowired
	private ReporteFacade reporteFacade;
	
	
	@RequestMapping(value = "consultarDatosReporte", method = RequestMethod.GET)
	public ResponseEntity<RespuestaDTO> consultarDatosReporte(
			@PathParam("idCliente") Integer idCliente, @PathParam("fecInicio") String fecInicio ,@PathParam("fecFin") String fecFin) {
		RespuestaDTO respuesta = new RespuestaDTO();
		try {
			respuesta = reporteFacade.getReporte().consultarDatosReporte(idCliente, fecInicio, fecFin);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<RespuestaDTO>(respuesta, HttpStatus.OK);
	}
}
