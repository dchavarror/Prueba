package co.com.colsubsidio.movimientos.banca.dao;

import java.util.Date;

import co.com.colsubsidio.movimientos.banca.dto.RespuestaDTO;

public interface IReporte {

	public RespuestaDTO consultarDatosReporte(final Integer idCliente, final String fecInicio, final String fecFin);

}
