package co.com.colsubsidio.movimientos.banca.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import co.com.colsubsidio.movimientos.banca.dao.ICuenta;

@Component
public class CuentaFacade {
	
	@Autowired
	private ICuenta cuenta;

	public ICuenta getCuenta() {
		return cuenta;
	}
}
